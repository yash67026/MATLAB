% -------- Simple MUSIC DoA example --------
clear; clc; close all;

% parameters
nelem = 10;               % number of ULA elements
d = 0.5;                  % element spacing (in wavelengths)
angles_true = [30, -10];  % two arrival angles (degrees)
nsig = length(angles_true);
snr = 5;                  % in dB

% compute covariance matrix using built-in
elementPos = (0:nelem-1)*d;  % positions in wavelengths
covmat = sensorcov(elementPos, angles_true, db2pow(-snr));

% estimate DoA using built-in
doas = musicdoa(covmat, nsig, 'ScanAngles', -90:0.5:90, 'ElementSpacing', d);
disp('Estimated DOAs (degrees):');
disp(doas);

% plot spatial spectrum
[doas2, spec, specang] = musicdoa(covmat, nsig, 'ScanAngles', -90:0.5:90, 'ElementSpacing', d);
figure;
plot(specang, 10*log10(spec));
xlabel('Angle (deg)'); ylabel('Spatial Spectrum (dB)');
title('MUSIC Spatial Spectrum');
grid on;
