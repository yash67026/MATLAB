clc; clear; close all;

%% Parameters
N = 128;               % Number of antenna elements (Massive MIMO)
d = 0.5;               % Element spacing in wavelengths
theta_true = [20 50];  % True DOAs in degrees
SNR = 20;              % Signal-to-noise ratio (dB)
snapshots = 200;       % Number of snapshots

%% Steering Vector Function
steeringVector = @(theta) exp(1j*2*pi*d*(0:N-1)'*sin(theta*pi/180));

%% Generate signals
K = length(theta_true); % Number of sources
s = (randn(K,snapshots) + 1j*randn(K,snapshots))/sqrt(2); % Random source signals
A = zeros(N,K);
for k = 1:K
    A(:,k) = steeringVector(theta_true(k));
end

X = A*s; % Received signal without noise
noise = (randn(N,snapshots) + 1j*randn(N,snapshots))/sqrt(2);
X = X + 10^(-SNR/20)*noise; % Add noise

%% Sample covariance matrix
R = (X*X')/snapshots;

%% Angle scan grid
theta_scan = 0:0.5:90;

%% ----------------- Bartlett -----------------
P_bartlett = zeros(size(theta_scan));
for i = 1:length(theta_scan)
    a = steeringVector(theta_scan(i));
    P_bartlett(i) = abs(a' * R * a);
end
P_bartlett = P_bartlett / max(P_bartlett);

%% ----------------- Capon / MVDR -----------------
P_capon = zeros(size(theta_scan));
for i = 1:length(theta_scan)
    a = steeringVector(theta_scan(i));
    P_capon(i) = 1 / real(a' * (R\ a)); % MVDR spectrum
end
P_capon = P_capon / max(P_capon);

%% ----------------- MUSIC -----------------
[eigVec, eigVal] = eig(R);
[~, idx] = sort(diag(eigVal), 'descend');
signalSubspace = eigVec(:, idx(1:K));
noiseSubspace = eigVec(:, idx(K+1:end));

P_music = zeros(size(theta_scan));
for i = 1:length(theta_scan)
    a = steeringVector(theta_scan(i));
    P_music(i) = 1 / real(a' * (noiseSubspace * noiseSubspace') * a);
end
P_music = P_music / max(P_music);

%% ----------------- ESPRIT -----------------
% Partition array (N must be even)
N1 = N/2;
Phi = pinv(X(1:N1,:)') * X(N1+1:end,:)';
[eVec_esprit, eVal_esprit] = eig(Phi);
theta_esprit = asin(angle(diag(eVal_esprit))/(pi*d)) * 180;

%% ----------------- Plot all in 2x2 Subplots -----------------
figure;

% Bartlett
subplot(2,2,1);
plot(theta_scan, 10*log10(P_bartlett),'r','LineWidth',2);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('Bartlett Spectrum');
grid on;

% Capon
subplot(2,2,2);
plot(theta_scan, 10*log10(P_capon),'g','LineWidth',2);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('Capon (MVDR) Spectrum');
grid on;

% MUSIC
subplot(2,2,3);
plot(theta_scan, 10*log10(P_music),'b','LineWidth',2);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('MUSIC Spectrum');
grid on;

% ESPRIT
subplot(2,2,4);
stem(theta_esprit, ones(size(theta_esprit)),'k','LineWidth',2);
xlabel('Angle (°)'); ylabel('Normalized Power');
title('ESPRIT Estimated DOAs');
grid on;