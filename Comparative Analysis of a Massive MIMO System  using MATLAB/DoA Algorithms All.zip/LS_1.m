clear; clc; close all;

% Simulation parameters
M = 20;                      % number of array elements
d = 0.5;                     % spacing in wavelengths
theta_true = [20 50];        % true angles (degrees)
K = length(theta_true);
N = 500;                     % snapshots
SNR_dB = 10;                 % single SNR value for now

lambda = 1;
k0 = 2*pi/lambda;
m = (0:M-1)';

% steering vector function
a = @(theta) exp(1j * k0 * d * sin(deg2rad(theta)) * m);

% Generate signals
sigma_n2 = 1 / (10^(SNR_dB/10));
S = (randn(K, N) + 1j*randn(K,N))/sqrt(2);
X = a(theta_true(1))*S(1,:) + a(theta_true(2))*S(2,:)*1 + sqrt(sigma_n2)*(randn(M,N)+1j*randn(M,N))/sqrt(2);

% Covariance
R = (X * X')/N;

% Grid search LS cost
theta_grid = 0:0.5:90;
cost_ls = zeros(size(theta_grid));
for i = 1:length(theta_grid)
    at = a(theta_grid(i));
    % project X onto at
    coeff = (at' * X)/(at'*at);
    X_est = at * coeff;
    cost_ls(i) = sum(sum(abs(X - X_est).^2));
end

% Find minimum cost
[~, idx_min] = min(cost_ls);
theta_est_ls = theta_grid(idx_min);
fprintf('Estimated DoA (LS style) ≈ %.2f degrees\n', theta_est_ls);

% Plot cost vs theta
figure;
plot(theta_grid, cost_ls, '-o');
xlabel('Angle θ (degrees)');
ylabel('Cost ‖X - a(θ) s‖²');
title('Grid-search LS Cost vs Angle');
grid on;
