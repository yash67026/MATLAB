clc; clear; close all;

%% Parameters
M = 20;                 % Number of sensors
d = 0.5;                % Element spacing (in wavelengths)
lambda = 1;             % Wavelength
theta_deg = [20 50];    % True directions of arrival
K = length(theta_deg);  % Number of sources
SNR = 20;               % Signal-to-noise ratio
snapshots = 200;        % Number of snapshots

%% Steering matrix and signal generation
theta = deg2rad(theta_deg);
A = exp(-1j*2*pi*d*(0:M-1)'*sin(theta));  % Steering matrix
S = randn(K, snapshots) + 1j*randn(K, snapshots); % Source signals
X = A*S;                                   % Received signals
X = awgn(X, SNR, 'measured');              % Add noise

%% Covariance matrix
R = (X*X')/snapshots;

%% -----------------------------------------
% 1️⃣  Bartlett Spectrum
%% -----------------------------------------
angles = 0:0.1:90;
P_bartlett = zeros(size(angles));
for i = 1:length(angles)
    a = exp(-1j*2*pi*d*(0:M-1)'*sin(deg2rad(angles(i))));
    P_bartlett(i) = abs(a' * R * a);
end
P_bartlett = 10*log10(P_bartlett / max(P_bartlett));

%% -----------------------------------------
% 2️⃣  Capon (MVDR) Spectrum
%% -----------------------------------------
P_capon = zeros(size(angles));
for i = 1:length(angles)
    a = exp(-1j*2*pi*d*(0:M-1)'*sin(deg2rad(angles(i))));
    P_capon(i) = 1 ./ abs(a' * (R \ a));
end
P_capon = 10*log10(P_capon / max(P_capon));

%% -----------------------------------------
% 3️⃣  MUSIC Spectrum
%% -----------------------------------------
[EV, D] = eig(R);
[~, idx] = sort(diag(D), 'descend');
En = EV(:, idx(K+1:end));  % Noise subspace
P_music = zeros(size(angles));
for i = 1:length(angles)
    a = exp(-1j*2*pi*d*(0:M-1)'*sin(deg2rad(angles(i))));
    P_music(i) = 1 / (a' * (En * En') * a);
end
P_music = 10*log10(P_music / max(P_music));

%% -----------------------------------------
% 4️⃣  ESPRIT Algorithm (Corrected)
%% -----------------------------------------
[U, D] = eig(R);
[~, order] = sort(diag(D), 'descend');
Es = U(:, order(1:K));  % Signal subspace

J1 = [eye(M-1), zeros(M-1,1)];
J2 = [zeros(M-1,1), eye(M-1)];
Psi = pinv(J1*Es) * (J2*Es);
phi = eig(Psi);

phase_phi = angle(phi);
sin_theta_est = - (phase_phi * lambda) / (2*pi*d);
sin_theta_est = max(min(real(sin_theta_est), 1), -1);
esprit_angles_deg = asind(sin_theta_est);
esprit_angles_deg = sort(real(esprit_angles_deg));

%% -----------------------------------------
% 5️⃣  Linear Prediction (LP) Method
%% -----------------------------------------
r = zeros(M,1);
for m = 1:M
    r(m) = mean(diag(R, m-1)); % estimate autocorrelation
end

% Build Toeplitz matrix for LP coefficients
R_lp = toeplitz(r(1:M-1));
rhs = -r(2:M);
a_lp = R_lp \ rhs;         % LP coefficients

% Construct polynomial
A_poly = [1; a_lp];
roots_lp = roots(flipud(A_poly));

% Keep only unit-circle roots (angles correspond to DOA)
angles_lp = asind(angle(roots_lp)/(2*pi*d/lambda));
angles_lp = real(angles_lp(abs(roots_lp) > 0.9 & abs(roots_lp) < 1.1));
angles_lp = sort(angles_lp);

%% -----------------------------------------
% 📊 Plot all results
%% -----------------------------------------
figure('Position',[100 100 1000 700]);

subplot(3,2,1);
plot(angles, P_bartlett, 'r','LineWidth',1.5);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('Bartlett Spectrum'); grid on;

subplot(3,2,2);
plot(angles, P_capon, 'g','LineWidth',1.5);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('Capon (MVDR) Spectrum'); grid on;

subplot(3,2,3);
plot(angles, P_music, 'b','LineWidth',1.5);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('MUSIC Spectrum'); grid on;

subplot(3,2,4);
stem(esprit_angles_deg, ones(size(esprit_angles_deg)), 'k','filled');
xlabel('Angle (°)'); ylabel('Normalized Power');
title('ESPRIT Estimated DOAs'); grid on;
axis([-90 90 0 1.2]);

subplot(3,2,5);
stem(angles_lp, ones(size(angles_lp)), 'm','filled');
xlabel('Angle (°)'); ylabel('Normalized Power');
title('Linear Prediction Estimated DOAs'); grid on;
axis([-90 90 0 1.2]);

%% Display numerical results
disp('True Angles (deg):');
disp(theta_deg);
disp('ESPRIT Estimated Angles (deg):');
disp(esprit_angles_deg);
disp('Linear Prediction Estimated Angles (deg):');
disp(angles_lp);
