clc; clear; close all;

%% Parameters
M = 20;                 % Number of array elements
d = 0.5;                % Element spacing (in wavelengths)
lambda = 1;             % Wavelength
theta_deg = [20 50];    % True angles (degrees)
K = length(theta_deg);  % Number of sources
SNR = 20;               % Signal-to-noise ratio (dB)
snapshots = 200;        % Number of snapshots

%% Array Steering Matrix
theta = deg2rad(theta_deg);
A = exp(-1j*2*pi*d*(0:M-1)'*sin(theta));

%% Generate signals + noise
S = randn(K, snapshots) + 1j*randn(K, snapshots);
X = A*S;
X = awgn(X, SNR, 'measured'); % Add white Gaussian noise

%% Covariance Matrix
R = (X*X')/snapshots;

%% ---- 1. Bartlett Spectrum ----
angles = 0:0.1:90;
P_bartlett = zeros(size(angles));
for i = 1:length(angles)
    a = exp(-1j*2*pi*d*(0:M-1)'*sin(deg2rad(angles(i))));
    P_bartlett(i) = abs(a' * R * a);
end
P_bartlett = 10*log10(P_bartlett / max(P_bartlett));

%% ---- 2. Capon (MVDR) Spectrum ----
P_capon = zeros(size(angles));
for i = 1:length(angles)
    a = exp(-1j*2*pi*d*(0:M-1)'*sin(deg2rad(angles(i))));
    P_capon(i) = 1./abs(a' * (R \ a));
end
P_capon = 10*log10(P_capon / max(P_capon));

%% ---- 3. MUSIC Spectrum ----
[EV, D] = eig(R);
[~, idx] = sort(diag(D), 'descend');
En = EV(:, idx(K+1:end)); % Noise subspace
P_music = zeros(size(angles));
for i = 1:length(angles)
    a = exp(-1j*2*pi*d*(0:M-1)'*sin(deg2rad(angles(i))));
    P_music(i) = 1 / (a' * (En * En') * a);
end
P_music = 10*log10(P_music / max(P_music));

%% ---- 4. ESPRIT Algorithm ----
% Partition into two subarrays
J1 = eye(M-1, M);
J2 = [zeros(M-1,1) eye(M-1,M-1)];
Rxx = R;
[EVs, Dv] = eig(Rxx);
[~, idx] = sort(diag(Dv), 'descend');
Es = EVs(:, idx(1:K)); % Signal subspace

% Solve the invariance equation
Psi = pinv(J1*Es) * (J2*Es);
phi = eig(Psi);

% Convert phase shifts to angles
esprit_angles = asind(angle(phi)/(2*pi*d/lambda));

%% ---- Plot Results ----
figure('Position',[100 100 1000 700]);

subplot(2,2,1)
plot(angles, P_bartlett, 'r','LineWidth',1.5);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('Bartlett Spectrum'); grid on; axis tight;

subplot(2,2,2)
plot(angles, P_capon, 'g','LineWidth',1.5);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('Capon (MVDR) Spectrum'); grid on; axis tight;

subplot(2,2,3)
plot(angles, P_music, 'b','LineWidth',1.5);
xlabel('Angle (°)'); ylabel('Normalized Power (dB)');
title('MUSIC Spectrum'); grid on; axis tight;

subplot(2,2,4)
stem(real(esprit_angles), ones(size(esprit_angles)), 'k','filled');
xlabel('Angle (°)'); ylabel('Normalized Power');
title('ESPRIT Estimated DOAs'); grid on; axis tight;

disp('ESPRIT Estimated Angles (degrees):');
disp(real(esprit_angles));
