% ================================================================
% DOA Estimation using LMS, MUSIC, and Linear Prediction Methods
% for a 1x4 Uniform Linear Antenna Array
% ================================================================
% Author: ChatGPT
% Date: 2025
% ================================================================

clear; close all; clc;

%% PARAMETERS
M = 4;                % Number of antenna elements (1x4 ULA)
d = 0.5;              % Element spacing (in wavelengths)
K = 2;                % Number of sources
DOA_true = [-25, 40]; % True Directions of Arrival (degrees)
Nsnap = 1000;         % Number of snapshots
SNRdB = 15;           % Signal-to-noise ratio in dB

mu = 0.01;            % LMS step size (for adaptive part)
iterations = Nsnap;   % Number of LMS updates

%% SIGNAL GENERATION
angles = DOA_true * pi/180;                   % Convert DOA to radians
A = exp(-1j*2*pi*d*(0:M-1).' * sin(angles));  % Steering matrix (M x K)
S = (randn(K, Nsnap) + 1j*randn(K, Nsnap)) / sqrt(2);  % Source signals
noise = (randn(M, Nsnap) + 1j*randn(M, Nsnap)) / sqrt(2);
X = A*S + 10^(-SNRdB/20) * noise;             % Received array data

%% ================================================================
% METHOD 1: LMS ADAPTIVE BEAMFORMING
% ================================================================
fprintf('\nRunning LMS Adaptive Beamforming...\n');

w = zeros(M,1);              % Initialize weight vector
x_ref = X(1,:);              % Reference input (can be first element)
y_out = zeros(1, iterations);% Output after beamforming
error = zeros(1, iterations);

for n = 1:iterations
    x_n = X(:, n);           % Snapshot at time n
    y_out(n) = w' * x_n;     % Array output
    d_n = x_ref(n);          % Desired signal (from first element)
    error(n) = d_n - y_out(n);
    w = w + mu * x_n * conj(error(n));   % LMS weight update
end

% LMS output power pattern estimation
scan_angles = -90:0.5:90;
P_LMS = zeros(size(scan_angles));

for i = 1:length(scan_angles)
    a = exp(-1j*2*pi*d*(0:M-1).' * sin(scan_angles(i)*pi/180));
    P_LMS(i) = abs(w' * a);
end

P_LMS_dB = 10*log10(abs(P_LMS) / max(abs(P_LMS)));

%% ================================================================
% METHOD 2: MUSIC ALGORITHM
% ================================================================
fprintf('Running MUSIC DOA Estimation...\n');

R = (X*X') / Nsnap;
R = (R + R') / 2;      % Force Hermitian

[U, D] = eig(R);
[d_sort, idx] = sort(diag(D), 'descend');
U = U(:, idx);
Un = U(:, K+1:end);    % Noise subspace

P_MUSIC = zeros(size(scan_angles));
for i = 1:length(scan_angles)
    a = exp(-1j*2*pi*d*(0:M-1).' * sin(scan_angles(i)*pi/180));
    P_MUSIC(i) = 1 / (a' * (Un * Un') * a);
end

P_MUSIC_dB = 10*log10(abs(P_MUSIC) / max(abs(P_MUSIC)));

%% ================================================================
% METHOD 3: LINEAR PREDICTION METHOD
% ================================================================
fprintf('Running Linear Prediction DOA Estimation...\n');

R_sub = R(1:M-1, 1:M-1);
r_vec = R(2:M, 1);
a = -R_sub \ r_vec;           % Predictor coefficients
poly_coeff = [1; a];
rts = roots(poly_coeff);

% Consider only roots near the unit circle
rts_on_unit = rts(abs(abs(rts) - 1) < 0.25);
theta_est_LP = asind(angle(rts_on_unit) / (2*pi*d));
theta_est_LP = real(theta_est_LP);

%% ================================================================
% DETECT MUSIC PEAKS
% ================================================================
[pks, locs] = findpeaks(P_MUSIC_dB, scan_angles, 'SortStr', 'descend');
est_DOA_MUSIC = locs(1:K);

%% ================================================================
% DISPLAY RESULTS
% ================================================================
fprintf('\n================ RESULTS ================\n');
fprintf('True DOAs: %s deg\n', mat2str(DOA_true));
fprintf('Estimated DOAs (LMS pattern peaks visually)\n');
fprintf('Estimated DOAs (MUSIC): %s deg\n', mat2str(est_DOA_MUSIC));
fprintf('Estimated DOAs (Linear Prediction): %s deg\n', mat2str(theta_est_LP));

%% ================================================================
% PLOTS
% ================================================================

% --- LMS Pattern ---
figure('Position',[100 100 900 600]);
subplot(3,1,1);
plot(scan_angles, P_LMS_dB, 'LineWidth', 1.5);
xline(DOA_true(1),'--r'); xline(DOA_true(2),'--r');
title('LMS Adaptive Beamforming Pattern (1×4 Array)');
xlabel('Angle (Degrees)'); ylabel('Normalized Power (dB)');
grid on; xlim([-90 90]);

% --- MUSIC Spectrum ---
subplot(3,1,2);
plot(scan_angles, P_MUSIC_dB, 'LineWidth', 1.5);
xline(DOA_true(1),'--r'); xline(DOA_true(2),'--r');
title('MUSIC Pseudospectrum (1×4 Array)');
xlabel('Angle (Degrees)'); ylabel('Normalized Power (dB)');
grid on; xlim([-90 90]);

% --- Linear Prediction Roots ---
subplot(3,1,3);
plot(real(rts), imag(rts), 'bo', 'LineWidth', 1.5); hold on;
plot(real(rts_on_unit), imag(rts_on_unit), 'ro', 'MarkerFaceColor','r');
viscircles([0 0], 1, 'LineStyle','--', 'Color',[0.6 0.6 0.6]);
axis equal; grid on;
xlabel('Real Part'); ylabel('Imaginary Part');
title('Roots of Linear Prediction Polynomial');

sgtitle('DOA Estimation using LMS, MUSIC, and Linear Prediction');
