% DoA_MassiveMIMO_Experiment.m
% Ready-to-run MATLAB script for DoA estimation experiments
% Methods: Phase-Difference, Bartlett (Conventional Beamformer), Capon (MVDR), MUSIC, ESPRIT
% Plots RMSE vs SNR and example spectra

clear; close all; clc;

rng(0); % for reproducibility

%% Parameters
M_list = [20];           % list of numbers of array elements to try (for now single value M=20)
d = 0.5;                 % element spacing in wavelengths (lambda normalized to 1)
lambda = 1;              % normalized wavelength
c = 3e8;                 % speed of light (not used except for freq conversions)
f = 3e9;                 % operating frequency (Hz) - not used in normalized sim

% Source/scenario
K = 2;                   % number of sources
theta_true = [10 15];    % true DOAs in degrees (ensure separation)
Nsnap = 500;             % number of snapshots
trials = 200;            % monte-carlo trials for RMSE calculation
SNR_dB_list = -5:5:20;   % SNRs to sweep

% Search grid for scanning methods
theta_grid = -90:0.25:90;

% Preallocate RMSE storage
rmse_pd = zeros(length(SNR_dB_list), length(M_list));
rmse_bart = zeros(size(rmse_pd));
rmse_capon = zeros(size(rmse_pd));
rmse_music = zeros(size(rmse_pd));
rmse_esprit = zeros(size(rmse_pd));

% Helper: steering vector for ULA
m = @(M) (0:M-1)';
steer = @(theta, M) exp(1j*2*pi*(d/lambda)*sin(deg2rad(theta)).*m(M));

% Main loop over array sizes (here only M=20)
for mi = 1:length(M_list)
    M = M_list(mi);
    fprintf('Running experiments for M = %d elements...\n', M);

    for si = 1:length(SNR_dB_list)
        SNRdB = SNR_dB_list(si);
        errs_pd = zeros(trials, K);
        errs_bart = zeros(trials, K);
        errs_capon = zeros(trials, K);
        errs_music = zeros(trials, K);
        errs_esprit = zeros(trials, K);

        for t = 1:trials
            % Generate source signals (complex Gaussian)
            S = (randn(K, Nsnap) + 1j*randn(K, Nsnap))/sqrt(2);
            X = zeros(M, Nsnap);
            for kk = 1:K
                X = X + steer(theta_true(kk), M) * S(kk, :);
            end
            % Add noise to achieve desired SNR per source (approx)
            signal_power = mean(abs(X(:)).^2);
            noise_power = signal_power / (10^(SNRdB/10));
            noise = sqrt(noise_power/2) * (randn(M, Nsnap) + 1j*randn(M, Nsnap));
            Xn = X + noise;

            % Sample covariance
            R = (Xn * Xn') / Nsnap;

            % 1) Phase-difference method (between element 1 & 2) - single source approx
            prod = mean(conj(Xn(1,:)) .* Xn(2,:));
            dphi = angle(prod);
            % unambiguous range check
            val = (lambda/(2*pi*d)) * dphi;
            if abs(val) <= 1
                theta_pd_est = asind(val);
            else
                theta_pd_est = NaN; % ambiguous
            end
            % For two sources, naive: pick which true angle it's closer to
            if ~isnan(theta_pd_est)
                [~, idxmin] = min(abs(theta_pd_est - theta_true));
                errs_pd(t, idxmin) = theta_pd_est - theta_true(idxmin);
            else
                errs_pd(t, :) = NaN;
            end

            % 2) Bartlett / Conventional beamformer (spatial scan)
            P_bart = zeros(size(theta_grid));
            for i = 1:length(theta_grid)
                at = steer(theta_grid(i), M);
                P_bart(i) = real(at' * R * at) / (at' * at);
            end
            % find K largest peaks
            [pks, locs] = findpeaks(abs(P_bart));
            if length(locs) >= K
                [~, idxp] = maxk(pks, K);
                theta_bart_est = theta_grid(locs(idxp));
            else
                % fallback: pick global maxima locations
                [~, idxs] = maxk(P_bart, K);
                theta_bart_est = theta_grid(idxs);
            end
            theta_bart_est = sort(theta_bart_est);
            errs_bart(t, :) = theta_bart_est - theta_true;

            % 3) Capon / MVDR
            P_capon = zeros(size(theta_grid));
            Rinv = pinv(R);
            for i = 1:length(theta_grid)
                at = steer(theta_grid(i), M);
                P_capon(i) = 1 / real(at' * Rinv * at);
            end
            [~, idxs] = maxk(P_capon, K);
            theta_capon_est = sort(theta_grid(idxs));
            errs_capon(t, :) = theta_capon_est - theta_true;

            % 4) MUSIC
            [V, D] = eig(R);
            [~, ind] = sort(diag(D), 'descend');
            V = V(:, ind);
            Un = V(:, K+1:end);
            P_music = zeros(size(theta_grid));
            for i = 1:length(theta_grid)
                at = steer(theta_grid(i), M);
                P_music(i) = 1 / (at' * (Un * Un') * at);
            end
            [~, idxs] = maxk(P_music, K);
            theta_music_est = sort(theta_grid(idxs));
            errs_music(t, :) = theta_music_est - theta_true;

            % 5) ESPRIT (basic implementation for ULA)
            % form signal subspace
            Us = V(:, 1:K);
            % selection matrices for overlapping subarrays of size M-1
            J1 = eye(M-1, M); J2 = [zeros(M-1,1) eye(M-1)];
            S1 = J1 * Us; S2 = J2 * Us;
            % least squares to find Psi
            Psi = pinv(S1) * S2;
            eigvals = eig(Psi);
            % extract angles from eigenvalues: eigvals = exp(j*2*pi*(d/lambda)*sin(theta))
            phi = angle(eigvals);
            theta_esprit_est = asind( (phi) / (2*pi*(d/lambda)) );
            if length(theta_esprit_est) >= K
                theta_esprit_est = sort(theta_esprit_est(1:K));
            else
                % pad
                theta_esprit_est = [theta_esprit_est; NaN(K-length(theta_esprit_est),1)];
            end
            errs_esprit(t, :) = theta_esprit_est' - theta_true;

        end % trials

        % Compute RMSE ignoring NaNs
        rmse_pd(si, mi) = sqrt(nanmean(nansum(errs_pd.^2, 2)) / K);
        rmse_bart(si, mi) = sqrt(nanmean(nansum(errs_bart.^2, 2)) / K);
        rmse_capon(si, mi) = sqrt(nanmean(nansum(errs_capon.^2, 2)) / K);
        rmse_music(si, mi) = sqrt(nanmean(nansum(errs_music.^2, 2)) / K);
        rmse_esprit(si, mi) = sqrt(nanmean(nansum(errs_esprit.^2, 2)) / K);

        fprintf('SNR = %ddB done. RMSE (deg): PD=%.3f, Bart=%.3f, Capon=%.3f, MUSIC=%.3f, ESPRIT=%.3f\n', ...
            SNRdB, rmse_pd(si,mi), rmse_bart(si,mi), rmse_capon(si,mi), rmse_music(si,mi), rmse_esprit(si,mi));

    end % SNR loop

end % M loop

%% Plot RMSE vs SNR
figure; hold on; grid on;
plot(SNR_dB_list, rmse_pd(:,1), '-o','DisplayName','PhaseDiff');
plot(SNR_dB_list, rmse_bart(:,1), '-s','DisplayName','Bartlett');
plot(SNR_dB_list, rmse_capon(:,1), '-d','DisplayName','Capon');
plot(SNR_dB_list, rmse_music(:,1), '-^','DisplayName','MUSIC');
plot(SNR_dB_list, rmse_esprit(:,1), '-v','DisplayName','ESPRIT');
xlabel('SNR (dB)'); ylabel('RMSE (degrees)'); title(sprintf('RMSE vs SNR (M=%d)', M_list(1)));
legend('Location','best');

%% Example spectra for last run (plot MUSIC / Bartlett / Capon)
figure; subplot(3,1,1);
plot(theta_grid, 10*log10(abs(P_bart))); xlabel('Angle (deg)'); ylabel('Power (dB)'); title('Bartlett Spectrum'); grid on;
subplot(3,1,2);
plot(theta_grid, 10*log10(abs(P_capon))); xlabel('Angle (deg)'); ylabel('Power (dB)'); title('Capon Spectrum'); grid on;
subplot(3,1,3);
plot(theta_grid, 10*log10(abs(P_music))); xlabel('Angle (deg)'); ylabel('Spectrum (dB)'); title('MUSIC Spectrum'); grid on;

fprintf('Experiment complete.\n');
