clc; clear; close all;

%% Parameters (same as your other methods)
M = 20;                 % elements
d = 0.5;                % spacing in wavelengths
lambda = 1;             % wavelength
theta_deg = [20 50];    % true DOAs
K = length(theta_deg);
SNR = 20;
snapshots = 200;

%% Steering & data
theta = deg2rad(theta_deg);
A = exp(-1j*2*pi*d*(0:M-1)'*sin(theta));
S = randn(K, snapshots) + 1j*randn(K, snapshots);
X = A*S;
X = awgn(X, SNR, 'measured');

%% Covariance
R = (X*X')/snapshots;

%% --- Signal subspace via eigen-decomposition / SVD
[U, D] = eig(R);
[~, order] = sort(diag(D), 'descend');
Es = U(:, order(1:K));     % M x K signal subspace

%% --- ESPRIT: correct selection matrices (shifted subarrays)
% Standard choice: J1 picks elements 1..M-1, J2 picks elements 2..M
J1 = [eye(M-1), zeros(M-1,1)];   % (M-1) x M
J2 = [zeros(M-1,1), eye(M-1)];   % (M-1) x M

% Solve invariant equation: Psi such that J2*Es ≈ J1*Es * Psi
Psi = pinv(J1 * Es) * (J2 * Es);  % K x K

% Eigenvalues of Psi
phi = eig(Psi);   % should be ~ exp(-j*2*pi*d*sin(theta)/lambda)

%% --- Convert eigenvalue phases to angles
% eigenvalue angle = arg(phi) = -2*pi*d*sin(theta)/lambda  (sign convention)
phase_phi = angle(phi);                       % in radians (-pi..pi)
sin_theta_est = - (phase_phi * lambda) / (2*pi*d);  % negative sign important
% Clip numerical errors to [-1,1] before asin
sin_theta_est = max(min(real(sin_theta_est), 1), -1);
esprit_angles_deg = asind(sin_theta_est);     % degrees

%% Sort & display
esprit_angles_deg_sorted = sort(esprit_angles_deg);
disp('ESPRIT Estimated Angles (deg):');
disp(esprit_angles_deg_sorted);

%% Quick plot (optional)
figure;
stem(esprit_angles_deg_sorted, ones(size(esprit_angles_deg_sorted)), 'k','filled');
xlabel('Angle (°)'); ylabel('Normalized Power');
title('ESPRIT Estimated DOAs'); grid on; axis([-90 90 0 1.2]);
